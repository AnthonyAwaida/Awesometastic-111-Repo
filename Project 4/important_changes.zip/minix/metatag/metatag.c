/*  Made by Falcon*/

#include <errno.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <minix/minlib.h>
#include <stdio.h>

int main (int argc, char *argv[]) {
	int fd;
	if (argc <= 2) {
		printf("Usage: metatag [filename] [metastring]\n");
		exit(0);
	}
	fd = open(argv[1], O_RDWR);
	if (fd < 0) {
		printf("metatag: %s not found!", argv[1]);
		exit(0);
	}
	if (argc == 3) {
		metawrite(fd, argv[2], strlen(argv[2]));
	} else {
		printf("metatag: Too many arguments!\n");
		exit(0);
	}
	exit(1);
}
