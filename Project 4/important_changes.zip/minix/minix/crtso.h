/* Prototypes for crtso.s. */

#ifndef _MINIX_CRTSO_H
#define _MINIX_CRTSO_H

_PROTOTYPE( void _minix_unmapzero, (void));

#endif
