#include <unistd.h>
#include <stdio.h>
#include <lib.h> 
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int metaread(int fd, void *buf, size_t count)
{
	message m;
	m.m1_i1 = fd;
	m.m1_i2 = count;
	m.m1_p1 = (char *) buf;
	printf("metareadddd\n");
	
	return (_syscall(VFS_PROC_NR, 105, &m));
}

int metawrite(int fd, const void *buf, size_t nbytes)
{
	message m;
	int i ;
	char * tester;
	m.m1_i1 = fd;
	m.m1_p1 = (char *) __UNCONST(buf);
	m.m1_i2 = nbytes;
    printf("metawriteeeeeee\n");
	tester = m.m1_p1;
	for(i = 0; i <nbytes; i++){
             printf("%c", *(tester++) );
            }
    printf("m.m1_p1 in test.c = %d\n",m.m1_p1);
   
/*	printf("pointer = %s\n", (char *) m.m1_p1);*/
	return (_syscall(VFS_PROC_NR, 106, &m));
}
void metacat(char *fname)
{
        int fd, n;
        char buf[2048];

        if ((fd = open(fname, O_WRONLY, 0)) < 0) {
                /*warn("%s", fname);
                (void)cleanup(); 
                exit(0);*/
        }
        metaread(fd, buf, sizeof(buf));
        printf("buf in metacat = %s\n", (char *)buf);
        if (n == -1) {
                /*warn("read");
                (void)cleanup();
                exit(0);*/
      }
        (void)close(fd);
}



int main (void) {
	char c;
	int file;
	char * works = "7654321";
	file = open("tester2.txt", O_RDWR);
	/*metawrite(file, works, 7);*/
    /*metaread(0, &c, 1);*/
    metacat("tester.txt");
    printf("%d\n",file);
    
	return 0;
}
